package com.hackathon.AdviseBetter.Service.Clustering.Training;

public class DataPoint {
 
	public String name;
	public Double count;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getCount() {
		return count;
	}
	public void setCount(Double count) {
		this.count = count;
	}
	public DataPoint(String name, Double count) {
		super();
		this.name = name;
		this.count = count;
	}
	
}
