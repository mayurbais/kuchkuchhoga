package com.hackathon.AdviseBetter.Service.Clustering.Training;

import java.util.Map;

import com.hackathon.AdviseBetter.Service.Clustering.Training.Product;

public class Record {

	public Product product;
	public  Map<String, Integer> dataPoints;
	public Record(Product product, Map<String, Integer> dataPoints) {
		super();
		this.product = product;
		this.dataPoints = dataPoints;
	}
}
