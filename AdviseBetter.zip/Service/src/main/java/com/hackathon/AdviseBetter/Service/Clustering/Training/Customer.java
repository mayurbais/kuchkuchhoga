package com.hackathon.AdviseBetter.Service.Clustering.Training;

public class Customer {

	public String custID;
	public String age;
	public String location;
	public String assumedPortfolioValue;
	
	public String getCustID() {
		return custID;
	}
	public void setCustID(String custID) {
		this.custID = custID;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getAssumedPortfolioValue() {
		return assumedPortfolioValue;
	}
	public void setAssumedPortfolioValue(String assumedPortfolioValue) {
		this.assumedPortfolioValue = assumedPortfolioValue;
	}
	
	
	public Customer(
			 String custID,
			 String age,
			 String location,
			 String assumedPortfolioValue){
		this.custID = custID;
		this.age = age;
		this.location = location;
		this.assumedPortfolioValue = assumedPortfolioValue;
		
		
	}


}
