package com.hackathon.AdviseBetter.Service.Clustering;


import java.util.Map;
import java.util.Objects;

import com.hackathon.AdviseBetter.Service.Clustering.Training.Product;

public class DataRecord {


	public Product product;
	public  Map<String, Double> dataPoints;
	public DataRecord(Product product, Map<String, Double> dataPoints) {
		this.product = product;
		this.dataPoints = dataPoints;
	}
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Map<String, Double> getDataPoints() {
		return dataPoints;
	}
	public void setDataPoints(Map<String, Double> dataPoints) {
		this.dataPoints = dataPoints;
	}
	
	public String getHeaderLable() {
		return this.product.productName;
		
	}
	
	 @Override
	    public boolean equals(Object o) {
	        if (this == o) {
	            return true;
	        }
	        if (o == null || getClass() != o.getClass()) {
	            return false;
	        }
	        DataRecord record = (DataRecord) o;
	        return Objects.equals(getHeaderLable(), record.getHeaderLable()) && Objects.equals(getDataPoints(), record.getDataPoints());
	    }

	    @Override
	    public int hashCode() {
	        return Objects.hash(getHeaderLable(), getDataPoints());
	    }
}

