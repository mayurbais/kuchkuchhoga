package com.hackathon.AdviseBetter.Service.Clustering;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hackathon.AdviseBetter.Service.Clustering.Training.Customer;

@SpringBootApplication
@RestController
@EnableEurekaClient
public class ServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceApplication.class, args);
	}
	
	 @RequestMapping
	  public String helloWorld() {
	     return "Hello P World";
	  }


		@RequestMapping("/customer")
		public List<Customer> getCustomer(){
			List<Customer> plist = new ArrayList<Customer>();
			
			for(int i=0;i<10;i++){
				Customer p = new Customer(i+"",i+"",i+"Location", i+"50000");
				plist.add(p);
			}
			
			return plist;
			
		}
		
}
