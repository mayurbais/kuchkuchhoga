package com.hackathon.AdviseBetter.Service.Clustering.Training;

import java.util.ArrayList;
import java.util.List;

import com.hackathon.AdviseBetter.Service.Clustering.DataRecord;

public class OutputDataRecord {

	public List<Product> productList = new ArrayList<Product>();
	public List<DataPoint> ageDataPoints = new ArrayList<DataPoint>();
	public List<DataPoint> locationDataPoints = new ArrayList<DataPoint>();
	public List<DataPoint> protofolioDataPoints = new ArrayList<DataPoint>();
	
	public List<Product> getProductList() {
		return productList;
	}
	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}
	public List<DataPoint> getAgeDataPoints() {
		return ageDataPoints;
	}
	public void setAgeDataPoints(List<DataPoint> ageDataPoints) {
		this.ageDataPoints = ageDataPoints;
	}
	public List<DataPoint> getLocationDataPoints() {
		return locationDataPoints;
	}
	public void setLocationDataPoints(List<DataPoint> locationDataPoints) {
		this.locationDataPoints = locationDataPoints;
	}
	public List<DataPoint> getProtofolioDataPoints() {
		return protofolioDataPoints;
	}
	public void setProtofolioDataPoints(List<DataPoint> protofolioDataPoints) {
		this.protofolioDataPoints = protofolioDataPoints;
	}
}
