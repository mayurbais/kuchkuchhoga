package com.hackathon.AdviseBetter.Service.Clustering.Training;

public class Product {

	public String prodId;
	public String productName;
	
	public String getProdId() {
		return prodId;
	}
	public void setProdId(String prodId) {
		this.prodId = prodId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}

}
