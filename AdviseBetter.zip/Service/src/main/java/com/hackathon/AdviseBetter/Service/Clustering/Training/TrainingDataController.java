package com.hackathon.AdviseBetter.Service.Clustering.Training;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hackathon.AdviseBetter.Service.Clustering.Centroid;
import com.hackathon.AdviseBetter.Service.Clustering.DataRecord;
import com.hackathon.AdviseBetter.Service.Clustering.EuclideanDistance;
import com.hackathon.AdviseBetter.Service.Clustering.KMeans2;
import static java.util.stream.Collectors.toSet;

@RestController
public class TrainingDataController {

	
	
	@RequestMapping("/trainingData/customerp")
	public List<Customer> getCustomer(){
		List<Customer> plist = new ArrayList<Customer>();
		Random random = new Random();
		for(int i=0;i<100;i++){
			Customer p = new Customer(i+"",random.nextInt(25)+"",random.nextInt(25)+"Location", random.nextInt(25)+"50000");
			plist.add(p);
		}
		
		for(int i=0;i<100;i++){
			Customer p = new Customer(i+"",50+random.nextInt(100)+"",50+random.nextInt(100)+"Location", 50+random.nextInt(100)+"50000");
			plist.add(p);
		}
		
		return plist;
		
	}
	
	@GetMapping("/trainingData/products")
	public List<Product> getProducts(){
		
		List<Product> plist = new ArrayList<Product>();
		
		Product p = new Product();
		p.prodId= "2";
		p.productName = "PrName2";
		plist.add(p);
		
		p = new Product();
		p.prodId= "1";
		p.productName = "PrName1";
		plist.add(p);
		
		p = new Product();
		p.prodId= "3";
		p.productName = "PrName3";
		plist.add(p);
		
		p = new Product();
		p.prodId= "4";
		p.productName = "PrName4";
		plist.add(p);
		
		p = new Product();
		p.prodId= "5";
		p.productName = "PrName5";
		plist.add(p);
	
		p = new Product();
		p.prodId= "7";
		p.productName = "PrName5";
		plist.add(p);
		
		p = new Product();
		p.prodId= "6";
		p.productName = "PrName5";
		plist.add(p);
		
		return plist;
		
	}
	
	@GetMapping("/trainingData/policies")
	public List<Policy> getPolicies(){
		
		List<Customer> custs = getCustomer();
		List<Policy> plist = new ArrayList<Policy>();
		
		for(int i=0;i<25;i++){
			Policy p = new Policy(i+"",custs.get(i),1+"",i+"L");
			
			plist.add(p);
		}
		for(int i=0;i<15;i++){
			Policy p = new Policy(i+"",custs.get(25+i),2+"",i+"L");
			plist.add(p);
		}
		
		for(int i=0;i<10;i++){
			Policy p = new Policy(i+"",custs.get(40+i),3+"",i+"L");
			plist.add(p);
		}
		for(int i=0;i<23;i++){
			Policy p = new Policy(i+"",custs.get(50+i),3+"",i+"L");
			plist.add(p);
		}
		for(int i=0;i<27;i++){
			Policy p = new Policy(i+"",custs.get(73+i),4+"",i+"L");
			plist.add(p);
		}
		for(int i=0;i<50;i++){
			Policy p = new Policy(i+"",custs.get(99+i),5+"",i+"L");
			plist.add(p);
		}
		for(int i=0;i<25;i++){
			Policy p = new Policy(i+"",custs.get(149+i),7+"",i+"L");
			plist.add(p);
		}
		for(int i=0;i<25;i++){
			Policy p = new Policy(i+"",custs.get(174+i),6+"",i+"L");
			plist.add(p);
		}
		return plist;
		
	}
	
	@GetMapping("/trainingData/records")
	public List<DataRecord> getDataPoints(){
		List<Policy> policies = getPolicies();
		List<Customer> customers = getCustomer();
		List<Product> products = getProducts();
		List<DataRecord> records = new ArrayList<DataRecord>();
		
	
		
		for(Product p:products){
			HashMap<String, Double> dataPointsCount = new HashMap<String, Double>(); 
			for(Policy pol:policies){
				if(p.getProdId().equals(pol.getProductId())){
					String keyName = "Age " + pol.getCust().getAge();
					Double value = dataPointsCount.get(keyName)==null?0.0:dataPointsCount.get(keyName);
					value = value+1.0;
					dataPointsCount.put(keyName,value);
					
					
					keyName = "Location " + pol.getCust().getLocation();
					value = dataPointsCount.get(keyName)==null?0.0:dataPointsCount.get(keyName);
					value = value+1.0;
					dataPointsCount.put(keyName,++value);
					
					keyName = "Portfoloio " + pol.getCust().getAssumedPortfolioValue();
					value = dataPointsCount.get(keyName)==null?0.0:dataPointsCount.get(keyName);
					value = value+1.0;
					dataPointsCount.put(keyName,++value);
					
				} 
			}
		
			records.add(new DataRecord(p,dataPointsCount));
			
		}
		
		return records;
		
	}
	
	@GetMapping("/trainingData/getCentroidAndRecords")
	//public Map<Centroid, List<DataRecord>>  getCentroidAndRecords() {
	public List<OutputDataRecord> getCentroidAndRecords() {
		List<DataRecord> dataRecords = getDataPoints();		
		Map<Centroid, List<DataRecord>> clusters = KMeans2.fit(dataRecords, 7, new EuclideanDistance(), 1000);
		
		List<OutputDataRecord> outputDataRecords = new ArrayList<OutputDataRecord>();
		
		clusters.forEach((key, value) -> {
          System.out.println("------------------------------ CLUSTER -----------------------------------");
          OutputDataRecord outputDataRecord = new OutputDataRecord();
          
          System.out.println(sortedCentroid(key));
          
          
          String members = String.join(", ", value
            .stream()
            .map(DataRecord::getHeaderLable)
            .collect(toSet()));
          
          
          outputDataRecord.setProductList(
	        		  	value
	        		  	.stream()
	        		  	.map(DataRecord::getProduct)
	        		  	.collect(Collectors.toList())
          );
          
          List<DataRecord> dataRecordList = value;
         
          
         for(DataRecord d: dataRecordList){
        	 Map<String, Double> dataPoints = d.getDataPoints();
	          dataPoints.forEach((point, count)->{
	        	  if(point.contains("Age")) {outputDataRecord.getAgeDataPoints().add(new DataPoint(point,count)); }
	        	  if(point.contains("Location")) {outputDataRecord.getLocationDataPoints().add(new DataPoint(point,count)); }
	        	  if(point.contains("Portfoloio")) {outputDataRecord.getProtofolioDataPoints().add(new DataPoint(point,count)); }
	        	  
	          });
         }
          
          
          outputDataRecords.add(outputDataRecord);
          
          System.out.print(members);

          System.out.println();
          System.out.println();
          
          
      });
		
		System.out.println("------------------------------ outputDataRecord -----------------------------------");
		outputDataRecords.forEach((OutputDataRecord outputDataRecord)->{
			System.out.println(outputDataRecord.getProductList().stream().map(Product::getProductName).collect(Collectors.toList()));
			System.out.println(outputDataRecord.getAgeDataPoints().stream().map(s->s.getName() + " || " + s.getCount()).collect(Collectors.toList()));
			System.out.println(outputDataRecord.getLocationDataPoints().stream().map(s->s.getName() + " || " + s.getCount()).collect(Collectors.toList()));
			System.out.println(outputDataRecord.getProtofolioDataPoints().stream().map(s->s.getName() + " || " + s.getCount()).collect(Collectors.toList()));
			
		});
		
	// return clusters;
	 
	 return outputDataRecords;
	}
	
	
	
	public void predict() {
		
		
	}
	
	
	private Centroid sortedCentroid(Centroid key) {
      List<Map.Entry<String, Double>> entries = new ArrayList<>(key
        .getCoordinates()
        .entrySet());
      entries.sort((e1, e2) -> e2
        .getValue()
        .compareTo(e1.getValue()));

      Map<String, Double> sorted = new LinkedHashMap<>();
      for (Map.Entry<String, Double> entry : entries) {
          sorted.put(entry.getKey(), entry.getValue());
      }

      return new Centroid(sorted);
  }
	
}
