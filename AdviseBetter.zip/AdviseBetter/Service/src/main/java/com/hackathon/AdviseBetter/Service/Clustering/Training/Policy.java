package com.hackathon.AdviseBetter.Service.Clustering.Training;

public class Policy {
 
	public String custID;
	public Customer cust;

	public String productId;
	public String MAVA;
	
	
	public String getCustID() {
		return custID;
	}
	public void setCustID(String custID) {
		this.custID = custID;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getMAVA() {
		return MAVA;
	}
	public void setMAVA(String mAVA) {
		MAVA = mAVA;
	}
	
	public Customer getCust() {
		return cust;
	}
	public void setCust(Customer cust) {
		this.cust = cust;
	}

	public  Policy(
			 String custID,
			 Customer cust,
			 String productId,
			 String MAVA){
		this.custID = custID;
		this.productId = productId;
		this.MAVA = MAVA;
		this.cust = cust;
		
	}
}
