package com.hackathon.AdviseBetter.Service.Clustering.Training;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController("/trainingData")
public class TrainingDataController {

	
	@GetMapping("/customer")
	public List<Customer> getCustomer(){
		List<Customer> plist = new ArrayList<Customer>();
		
		for(int i=0;i<10;i++){
			Customer p = new Customer(i+"",i+"",i+"Location", i+"50000");
			plist.add(p);
		}
		
		return plist;
		
	}
	
	@GetMapping("/products")
	public List<Product> getProducts(){
		
		List<Product> plist = new ArrayList<Product>();
		
		Product p = new Product();
		p.prodId= "2";
		p.productName = "PrName2";
		plist.add(p);
		
		p = new Product();
		p.prodId= "1";
		p.productName = "PrName1";
		plist.add(p);
		
		p = new Product();
		p.prodId= "3";
		p.productName = "PrName3";
		plist.add(p);
		
		p = new Product();
		p.prodId= "3";
		p.productName = "PrName3";
		plist.add(p);
		
		
		return plist;
		
	}
	
	@GetMapping("/policies")
	public List<Policy> getPolicies(){
		
		List<Customer> custs = getCustomer();
		List<Policy> plist = new ArrayList<Policy>();
		
		for(int i=0;i<10;i++){
			Policy p = new Policy(i+"",custs.get(i),i+"",i+"L");
			plist.add(p);
		}
		
		return plist;
		
	}
	
	@GetMapping("/records")
	public List<Record> getDataPoints(){
		List<Policy> policies = getPolicies();
		List<Customer> customers = getCustomer();
		List<Product> products = getProducts();
		List<Record> records = new ArrayList<Record>();
		for(Product p:products){
			HashMap<String, Integer> dataPointsCount = new HashMap<String, Integer>(); 
			for(Policy pol:policies){
				if(p.getProdId() == pol.getProductId()){
					String keyName = "Age " + pol.getCust().getAge();
					Integer value = dataPointsCount.get(keyName);
					value = (value == null)? dataPointsCount.put(keyName,0):dataPointsCount.put(keyName,value++);
					
					keyName = "location " + pol.getCust().getLocation();
					value = dataPointsCount.get(keyName);
					value = (value == null)? dataPointsCount.put(keyName,0):dataPointsCount.put(keyName,value++);
					
					keyName = "portfoloio " + pol.getCust().getAssumedPortfolioValue();
					value = dataPointsCount.get(keyName);
					value = (value == null)? dataPointsCount.put(keyName,0):dataPointsCount.put(keyName,value++);
					
				}
			}
		
			records.add(new Record(p,dataPointsCount));
			
		}
		
		return records;
		
	}
	
	
}
