package com.hackathon.AdviseBetter.Service.Clustering.Training;

public class DataPoint {
  public String name;
  public String count;
}
